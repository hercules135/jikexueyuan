﻿<?php

	$link = mysqli_connect('localhost','root','1234','baidunews',8889);

	
	
?>