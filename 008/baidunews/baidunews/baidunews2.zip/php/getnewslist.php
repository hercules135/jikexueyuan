﻿<?php

	//require_once("db.php");
	header("Content-type:application/json;charset=utf-8");
	$link = mysqli_connect('localhost','root','1234','baidunews',8889);

	$sql="select * from news";  
	mysqli_query($link,"SET NAMES utf8");
	$rs= mysqli_query($link,$sql);
	$result["data"] = array();
	while ($row =mysqli_fetch_assoc($rs)) {
		array_push($result["data"] , $row);
	}
	error_log(json_encode($result));
	echo json_encode($result);
?>