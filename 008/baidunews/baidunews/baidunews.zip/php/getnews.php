﻿<?php

	header("Content-type:application/json;charset=utf-8");
	$link = mysqli_connect('localhost','root','1234','baidunews',8889);


	$sql="select * from news";  
	mysqli_query($link,"SET NAMES utf8");
	$rs= mysqli_query($link,$sql);
	var_dump($rs);
	while ($row =mysqli_fetch_assoc($rs)) {
		var_dump($row);
		echo $row['title'];
	}

	
?>