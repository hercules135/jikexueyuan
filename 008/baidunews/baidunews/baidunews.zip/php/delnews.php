﻿<?php

	header("Content-type:application/json;charset=utf-8");
	$link = mysqli_connect('localhost','root','1234','baidunews',8889);

	$id=$_POST["id"];
	$sql="delete from news where id = '{$id}'"; 
	error_log($sql);
	mysqli_query($link,"SET NAMES utf8");
	$rs= mysqli_query($link,$sql);
	if ($rs) {
		echo true;
	}
	else{
		echo false;
	}
	

	
?>