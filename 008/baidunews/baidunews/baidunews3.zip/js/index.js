﻿$(function () {

    //初始化doT模板
    var adapter = doT.template($("#item").html());

    var type = "精选";
    $(".cl li").click(function () {
        type = $(this).text();
        $(".itemlist").empty();
        getlist();
    });

    //获取列表方法
    var getlist = function () {
        $.ajax({

            url: "php/getnewslist.php",
            type: "get",
            data: { type: type },
            datatype: "json",
            beforeSend: function () {

            },
            success: function (re) {
                debugger;
                //$(".itemlist").empty();
                $(".itemlist").append(adapter(re.data));
            }
        })
    }
    getlist();

    $(".more").click(function () {
        getlist();
    });

})