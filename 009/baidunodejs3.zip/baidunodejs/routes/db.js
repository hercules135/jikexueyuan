module.exports = {
	host     : 'localhost',
	port	:'8889',
	user     : 'root',
	password : '1234',
	database : 'baidunews'
};