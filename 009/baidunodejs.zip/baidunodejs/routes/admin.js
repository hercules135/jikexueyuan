var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var connection = mysql.createPool({
		host     : 'localhost',
		port	:'8889',
		user     : 'root',
		password : '1234',
		database : 'baidunews'
	});
//保存修改
router.post('/editnews', function(req, res, next) {
	console.log(req);
	var id = req.body.id;
	var title = req.body.title,
	picturesrc = req.body.picturesrc,
	src = req.body.src,
	time = req.body.time;

	var sql="update `news` set `title`='"+title+"',`picturesrc`='"+picturesrc+"',`src`='"+src+"',`time`='"+time+"' where id = '"+id+"'";  
	console.log(sql);
	connection.query(sql,[],function(err,rows){
		
		res.json(true);
	});
});

//添加
router.post('/addnews', function(req, res, next) {
	connection.query('',[],function(err,rows){

	var title = req.body.title;
	var picturesrc = req.body.picturesrc;
	var src = req.body.src;
	var time = req.body.time;

	var sql="INSERT INTO `news` (`title`,`picturesrc`,`src`,`time`) VALUES ('"+title+"', '"+picturesrc+"','"+src+"','"+time+"')";  
console.log(sql);
	connection.query(sql,[],function(err,rows){
		
		res.json(true);
	});

	});
});

//删除
router.post('/delnews', function(req, res, next) {
	connection.query('',[],function(err,rows){


		var id=req.body.id;
		var sql="delete from news where id = '"+id+"'"; 
		console.log(sql);
		connection.query(sql,[],function(err,rows){
			
			res.json(true);
		});
	});
});

module.exports = router;
