<?php

	header("Content-type:application/json;charset=utf-8");
	$link = mysqli_connect('localhost','root','1234','baidunews',8889);

	
	
?>